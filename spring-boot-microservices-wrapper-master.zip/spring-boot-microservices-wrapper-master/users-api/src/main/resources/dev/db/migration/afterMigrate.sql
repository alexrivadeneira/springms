INSERT INTO USERS
  (USER_NAME, FIRST_NAME, LAST_NAME)
VALUES
  ('user from seeds', 'blah', 'blah'),
  ('another user', 'another', 'users'),
  ('someone', 'ahhhh', 'jflsdkfj'),
  ('someone else', 'fjfjfjfjf', 'done');